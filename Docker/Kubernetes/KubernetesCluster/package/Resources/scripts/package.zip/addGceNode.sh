#!/bin/bash
echo "Adding Gce Node $1" >> /tmp/autoscale.log
sudo bash /opt/bin/autoscale/addGceNode.sh $1
