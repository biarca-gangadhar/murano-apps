#!/bin/bash

#
# command line arguments
#

# $1  - max_vms_limit 
# $2  - min_vms_limit
# $3  - MAX_CPU_LIMIT
# $4  - MIN_CPU_LIMIT
# $5  - MASTER
# $6  - env_name
# $7  - OPENSTACK_IP
# $8  - tenant
# $9  - username
# $10 - password
# $11 - Enabe Hybrid Cloud 
# $12 - GCP Minion Node
# $13 - GCP Node Detaileos
# $14 - GCP Username
# $15 - GCP Password
# $16 - Auto Create/Delete GCE nodes
# $17 - OpenVPN IP
# $18 - GCP Auth Code
# $19 - GCP Minions Count
# $20 - GCP Project ID

log_file=/var/log/autoscale.log
echo "Auto Scale setup starting" >> $log_file
conf_file=auto_scale/autoscale.conf

mkdir -p /etc/autoscale
mkdir -p /opt/bin/autoscale

sed -i "/^\[DEFAULT]/ a\max_vms_limit=${1}" $conf_file
sed -i "/^\[DEFAULT]/ a\min_vms_limit=${2}" $conf_file
sed -i "/^\[DEFAULT]/ a\MAX_CPU_LIMIT=${3}" $conf_file
sed -i "/^\[DEFAULT]/ a\MIN_CPU_LIMIT=${4}" $conf_file
sed -i "/^\[DEFAULT]/ a\MASTER=${5}" $conf_file
sed -i "/^\[DEFAULT]/ a\env_name=${6}" $conf_file
sed -i "/^\[DEFAULT]/ a\password=${10}" $conf_file
sed -i "/^\[DEFAULT]/ a\tenant=${8}" $conf_file
sed -i "/^\[DEFAULT]/ a\username=${9}" $conf_file
sed -i "/^\[DEFAULT]/ a\OPENSTACK_IP=${7}" $conf_file
   if [[ ${11} == "True" ]];
   then
      sed -i "/^\[GCE]/ a\gcp_ip=${13}" $conf_file
      sed -i "/^\[GCE]/ a\gcp_minion_nodes=${12}" $conf_file
      sed -i "/^\[GCE]/ a\gcp_password=${15}" $conf_file
      sed -i "/^\[GCE]/ a\gcp_username=${14}" $conf_file
      sed -i "/^\[GCE]/ a\GCP_MINION_COUNT=${19}" $conf_file
      sed -i "/^\[GCE]/ a\OPENVPN_SERVER_IP=${17}" $conf_file
      sed -i "/^\[GCE]/ a\GCP_AUTHCODE=${18}" $conf_file
      sed -i "/^\[GCE]/ a\GCP_PROJECT_ID=${20}" $conf_file
      mkdir -p /opt/bin/autoscale/kube
      mkdir -p /opt/bin/autoscale/kube/initd
      mkdir -p /opt/bin/autoscale/gce
      mkdir -p /opt/bin/autoscale/gce/templates
      cp auto_scale/addGceNode.sh /opt/bin/autoscale/
      cp auto_scale/deleteGceNode.sh /opt/bin/autoscale/
      cp auto_scale/gceIpManager.sh /opt/bin/autoscale/
      cp auto_scale/kube/reconfDocker.sh /opt/bin/autoscale/kube
      cp auto_scale/kube/initd/etcd /opt/bin/autoscale/kube/initd
      cp auto_scale/kube/initd/flanneld /opt/bin/autoscale/kube/initd
      cp auto_scale/kube/initd/kubelet /opt/bin/autoscale/kube/initd
      cp auto_scale/kube/initd/kube-proxy /opt/bin/autoscale/kube/initd
      cp auto_scale/gce/authtoken.sh /opt/bin/autoscale/gce/authtoken.sh
      sudo bash /opt/bin/autoscale/gce/authtoken.sh code ${18}
      cp auto_scale/gce/compute_api.sh /opt/bin/autoscale/gce/compute_api.sh
      cp auto_scale/gce/createGceNode.sh /opt/bin/autoscale/gce/createGceNode.sh
      cp auto_scale/gce/deleteGceNode.sh /opt/bin/autoscale/gce/deleteGceNode.sh
      cp auto_scale/gce/json-data.sh /opt/bin/autoscale/gce/json-data.sh
      cp auto_scale/gce/templates/create.template /opt/bin/autoscale/gce/templates
      cp auto_scale/gce/templates/disk.template /opt/bin/autoscale/gce/templates
   fi
cp auto_scale/autoscale.conf /etc/autoscale/
chmod +x auto_scale/*
cp auto_scale/metrics.py /opt/bin/autoscale/
cp auto_scale/scale.sh /opt/bin/autoscale/
cp auto_scale/autoscale /etc/init.d/
sudo apt-get install python3-numpy -y
sudo apt-get install jq
sudo apt-get install sshpass -y
service autoscale start
if [ ! -f  ~/.ssh/id_rsa ] ; then
            ssh-keygen -f ~/.ssh/id_rsa -t rsa -N ''
fi
exit 0

