#!/bin/bash

# $1 - action [ insert | create-disk  ]
# $2 - instance name
# $3 - project id

if [ $# -eq 0 ] ; then
    echo "Invalid args"
    exit 0
fi

INST_NAME=$2
PROJECT_ID=$3

SSH_ID=$(cat ~/.ssh/id_rsa.pub)
SCRIPTS_PATH="/opt/bin/autoscale/gce"

function data() {
    TEMPLATE=$1
    TMP_FILE=$2
    
    cp $TEMPLATE $TMP_FILE
    sed -i "s/%%NAME%%/$INST_NAME/g" $TMP_FILE
    sed -i "s/%%PROJECT_ID%%/$PROJECT_ID/g" $TMP_FILE
    sed -i "s|%%SSH_ID%%|$SSH_ID|g" $TMP_FILE
    temp=`tr "\n" " " < $TMP_FILE` 
    DATA=`echo $temp`
    rm $TMP_FILE
}


case "$1" in
    insert)
        data ${SCRIPTS_PATH}/templates/create.template /tmp/create
        echo $DATA
        ;;
    create-disk)
        data ${SCRIPTS_PATH}/templates/disk.template /tmp/disk
        echo $DATA
        ;;
    *) 
        echo "Unknow action: $1"
        exit 1
esac
