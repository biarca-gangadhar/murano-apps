#!/bin/bash

set -e

LOG_FILE="/var/log/gce.log"
function LOG()
{
    echo "$1: $2" >> $LOG_FILE
}

LOG "I" "Removing SSH key of $IP if exist"
# setup ssh without asking yes/no
if [ -f ~/.ssh/known_hosts ]; then
    ssh-keygen -f ~/.ssh/known_hosts -R ${IP} &> /dev/null 
fi
LOG "I" "Adding new SSH key of $IP"
ssh-keyscan ${IP} >> ~/.ssh/known_hosts 2> /dev/null
LOG "I" "Checking date"
ssh root@${IP} date >> $LOG_FILE
exit 0

LOG_FILE="/var/log/autoscale.log"
SCRIPTS_PATH="/opt/bin/autoscale/gce"
conf_file="/etc/autoscale/autoscale.conf"
PROJ_ID=$(awk -F "=" '/^GCP_PROJECT_ID/ {print $2}' $conf_file)
if [ -z $PROJ_ID ] ; then
    echo "Error: PROJECT ID not found"
    exit 1
fi
VPN_SERVER_IP=$(awk -F "=" '/^VPN_SERVER_IP/ {print $2}' $conf_file)
RANDOM_STR=`cat /dev/urandom | tr -dc 'a-z0-9' | fold -w ${1:-12} | head -n 1`
NAME="murano-k8s-$RANDOM_STR"
function LOG()
{
    echo $1 >> $LOG_FILE
}

LOG "Creating boot disk '$NAME'"
bash ${SCRIPTS_PATH}/compute_api.sh create-disk -n $NAME -p $PROJ_ID
LOG "Creating instance '$NAME'"
bash ${SCRIPTS_PATH}/compute_api.sh insert -n $NAME -p $PROJ_ID
IP=$(bash ${SCRIPTS_PATH}/compute_api.sh get --ip -n $NAME -p $PROJ_ID)
LOG "Instance created with external IP '$IP'"
echo $IP
