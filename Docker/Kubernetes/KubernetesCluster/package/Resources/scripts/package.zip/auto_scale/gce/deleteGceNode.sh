#!/bin/bash

set -e

LOG_FILE="/var/log/autoscale.log"
SCRIPTS_PATH="/opt/bin/autoscale/gce"
echo "Deleting instance '$1'" >> $LOG_FILE
bash ${SCRIPTS_PATH}/compute_api.sh delete -n $1 -p $2
