#!/bin/bash
# $1 - refresh  | code
# $2 - <code> if $1=code
set -e

action=$1
code=$2
args_count=$#
conf_file="/etc/autoscale/autoscale.conf"
refresh_token_file="/etc/autoscale/refresh_token.json"
token_file="/etc/autoscale/token.json"
LOG_FILE="/var/log/gce.log"

function usage() {
        echo ""
        echo "Usage: $0 [refresh|code|get] <code>"
        echo "Eg-1: $0 refresh"
        echo "Eg-2: $0 code y20.fd_2jdks45KIHBK4XXX"
        echo ""
}

function LOG() 
{
    # $1 - error/info, $2 - message
    # if [ "D" != "$1" ] ; then
        echo "$(date '+%Y/%m/%d %H:%M:%S') - $1: $2 (F:$0)" >> $LOG_FILE
    # fi
}

function check-args() 
{
    if [ $args_count -lt 1 ] || [ $args_count -gt 2 ] ; then
        usage
        exit 1
    fi
    if [ $action != "code" ] && [ $action != "refresh" ] && [ $action != "get" ]; then
        echo "Unkown action: $action"
        usage
        exit 1
    fi
    if [ $action == "code" ] && [ -z $code ] ; then 
        echo "Please enter the code"
        usage
        exit 1
    fi
    if [ $action == "refresh" ] && [ ! -z $code ] ; then
        echo "Unknown arg: $2"
        usage
        exit 1
    fi
}

# returns "null" if it's a vaild token
function validate-token()
{
    LOG "I" "Validating token"
    if [ ! -f $token_file ]; then
        LOG "E" "Missing token file ($token_file)"
        return 1
    fi
    token=$(cat $token_file | jq --raw-output ".access_token")
    if [ $token == "null" ] ; then
        LOG "E" "Token not found ($token_file)"
        return 1
    fi
   
    url="https://www.googleapis.com/oauth2/v1/tokeninfo?access_token=$token"
    LOG "D" "GET $url"
    resp=`curl -s $url`
    LOG "D" "Response $resp"
    result=`echo $resp | jq ".error"`
    echo $result
    return 0
}

function req-auth-token()
{
    LOG "I" "Requesting access token"
    url="https://www.googleapis.com/oauth2/v3/token"
    client_secret="XRMJDbiezqVfuDAhQh-rGM5E"
    client_id="140806339056-6ffngmf0eisguuhq9pif6am87p8a8lp0.apps.googleusercontent.com"
    redirect_uri="urn:ietf:wg:oauth:2.0:oob"
    access_type="offline"
    grant_type="authorization_code"
    
    data="code=$code&client_id=$client_id&client_secret=$client_secret&redirect_uri=$redirect_uri&grant_type=$grant_type&access_type=$access_type"
    LOG "D" "POST $url"
    LOG "D" "DATA $data"
    resp=`curl -s --data "$data" $url`
    LOG "D" "Response $resp"
    echo $resp > $refresh_token_file
    cp $refresh_token_file $token_file
}

function refresh-auth-token() 
{
    LOG "I" "Refreshing access token"
    if [ ! -f $refresh_token_file ] ; then
        LOG "E" "Refresh token file not fount (File: $refresh_token_file)"
        exit 1
    fi
    
    url="https://www.googleapis.com/oauth2/v3/token"
    client_id="140806339056-6ffngmf0eisguuhq9pif6am87p8a8lp0.apps.googleusercontent.com"
    client_secret="XRMJDbiezqVfuDAhQh-rGM5E"
    refresh_token=`cat $refresh_token_file | jq --raw-output  ".refresh_token"`
    grant_type="refresh_token"
   
    if [ -z $refresh_token ] || [ $refresh_token == "null" ]; then
        LOG "E" "Refresh token not found. Login again"
        exit 1
    fi

    data="client_id=$client_id&client_secret=$client_secret&refresh_token=$refresh_token&grant_type=$grant_type"
    LOG "D" "POST $url"
    LOG "D" "DATA $data" 
    resp=`curl -s --data "$data" $url`
    LOG "D" "Response $resp"

    echo $resp > $token_file   
}

check-args

case "$action" in 
    code) 
        req-auth-token
        ;;
    refresh)
        refresh-auth-token
        ;;
    get)
        if [ ! -f $refresh_token_file ] && [ ! -f $token_file ]
        then
            LOG "W" "No Tokens found. Requesting new token"
            code=$(awk -F "=" '/^GCP_AUTHCODE/ {print $2}' $conf_file)
            req-auth-token
        fi
        result=$(validate-token)
        if [ $? -ne 0 ] ;  then
            LOG "E" "Token validation failed"
            exit 0
        fi
        if [ $result == "null" ] ; then
	    LOG "I" "Token is valid"
            jq --raw-output ".access_token" $token_file
        else
            LOG "I" "Token Expired"
            refresh-auth-token
            jq --raw-output ".access_token" $token_file
        fi
        ;; 
esac
