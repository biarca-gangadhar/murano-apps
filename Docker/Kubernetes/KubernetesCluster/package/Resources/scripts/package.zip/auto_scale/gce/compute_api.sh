#!/bin/bash

set -e


if [ $# -eq 0 ]; then
    echo "Invalid args"
    exit 0
fi

ACTIONS=(insert delete create-disk get me --email)
if [[ " ${ACTIONS[@]} " =~ " ${1} " ]]; then
    ACTION=$1
else
    echo "Unknow action: $1"
    exit 1
fi

# Execute getopt
ARGS=$(getopt -o p:z:n: -l "project:,zone:,name:,ip,email" -n "$0" -- "$@");

#Bad arguments
if [ $? -ne 0 ];
then
  echo "Bad arguments"
  exit 1
fi

eval set -- "$ARGS";

while true; do
  case "$1" in
    -p|--project)
      shift;
      if [ -n "$1" ]; then
          PROJECT_ID=$1
          shift;
      fi
      ;;
    -z|--zone)
      shift;
      if [ -n "$1" ]; then
        ZONE=$1
        shift;
      fi
      ;;
    -n|--name)
      shift;
      if [ -n "$1" ]; then
        NAME=$1
        shift;
      fi
      ;;
    --ip)
      shift;
      ONLY_IP=true
      ;;
    --email)
      shift;
      EMAIL=true
      ;;
    --)
      shift;
      break;
      ;;
  esac
done

if [ $ACTION == "me" ] || [ $ACTION == "--email" ]; then
    ACTION=me
    PROJECT_ID=none
    NAME=none
fi

if [ -z $PROJECT_ID ]; then
    echo "Missing project ID"
    exit 0
fi

if [ -z $NAME ]; then
    echo "Missing instance name"
    exit 0
fi

if [ -z $ZONE ]; then
    ZONE="us-central1-f"
fi

SCRIPTS_PATH="/opt/bin/autoscale/gce"
token_file="/opt/bin/autoscale/gce/authtoken.sh"
ACCESS_TOKEN=$(bash $token_file get)
LOG_FILE="/var/log/gce.log"
# (D-Debig, I-Info, W-Warning, E-Error)
function LOG()
{
   # $1 - log level, $2 - msg
   # if [ "D" != "$1" ] ; then
        echo "$(date '+%Y/%m/%d %H:%M:%S') - $1: $2" >> "$LOG_FILE"
   # fi
}

function task_done()
{
    # $1 - task url
    if [ $1 == "null" ] ; then
        LOG "E" "Invalid  URL '$1'"
        exit 0
    fi
    LOG "I" "Polling Task.."
    local attempts=20
    while true
    do
        ((attempts=attempts-1))
        if [ $attempts -eq 0 ] ; then
            LOG "E" "Timeout 80sec.."
            echo "Timeout"
            break
        else
           sleep 4
           LOG "I" "GET $1"
           resp=`curl -s $1?access_token=$ACCESS_TOKEN`
           LOG "I" "Response $resp"    
           status=`echo $resp | jq --raw-output ".status"`
           if [ $status == "DONE" ]; then
               LOG "I" "Task finished"
               echo "DONE"
               break
           else 
               #echo "$status"
               continue
	   fi
           
        fi
    done
}

function get-instance-details()
{
    api="https://www.googleapis.com/compute/v1/projects/$PROJECT_ID/zones/$ZONE/instances/$NAME"
    url="$api?access_token=$ACCESS_TOKEN"
    LOG "D" "GET $url"
    result=`curl -s $url`
    LOG "D" "Response $result"
    echo $result
}

function create-instance()
{
    api="https://www.googleapis.com/compute/v1/projects/$PROJECT_ID/zones/$ZONE/instances" 
    url="$api?access_token=$ACCESS_TOKEN"
    headers="Content-type: application/json"
    data=`bash $SCRIPTS_PATH/json-data.sh insert $NAME $PROJECT_ID`
    LOG "D" "POST $url"
    LOG "D" "HEADERS $headers"
    LOG "D" "DATA $data"
    result=`curl -s -H "$headers" --data "$data" $url`
    LOG "D" "Response $result"
    echo $result
}

function delete-instance()
{
   
    api="https://www.googleapis.com/compute/v1/projects/$PROJECT_ID/zones/$ZONE/instances/$NAME"
    url="$api?access_token=$ACCESS_TOKEN"
    LOG "D" "DELETE $url"
    result=`curl -s -X "DELETE" $url`
    LOG "D" "Response $result"
    echo $result
}

case "$ACTION" in
    insert) 
        LOG "i" "Creating instance '$NAME'"
        result=$(create-instance)
        progress_url=`echo $result | jq --raw-output ".selfLink"`
        status=$(task_done $progress_url)
        if [ -z $status ]; then
            LOG "E" "Task failed"
            exit 1
        fi 
        if [ $status != "DONE" ]; then
            LOG "E" "Timeout 40sec.. CREATE '$NAME'"
            # echo "Timeout"
            exit 1
        else
            LOG "I" "Instance '$NAME' created"
        fi
        ;;
    delete)
        LOG "I" "Deleting instance '$NAME'"
        result=$(delete-instance)
        progress_url=`echo $result | jq --raw-output ".selfLink"`
        status=$(task_done $progress_url)
        if [ -z $status ]; then
            LOG "E" "Task failed"
            exit 1
        fi 
        if [ $status != "DONE" ]; then
            LOG "E" "Timeout 40sec.. DELETE '$NAME'"
            exit 1
        else
            LOG "I" "Instance '$NAME' deleted"
        fi
        ;;
    create-disk)
        LOG "I" "Creating disk '$NAME'"
        if [ ! -f  ~/.ssh/id_rsa ] ; then
            ssh-keygen -f ~/.ssh/id_rsa -t rsa -N ''
        fi 
	api="https://www.googleapis.com/compute/v1/projects/$PROJECT_ID/zones/$ZONE/disks"
        url="$api?access_token=$ACCESS_TOKEN"
        headers="Content-type: application/json"
        data=`bash $SCRIPTS_PATH/json-data.sh create-disk $NAME $PROJECT_ID`
        LOG "D" "POST $url"
        LOG "D" "HEADERS $headers"
        LOG "D" "DATA $data"
        result=`curl -s -H "$headers" --data "$data" $url`
        LOG "D" "Response $result"
        progress_url=`echo $result | jq --raw-output ".selfLink"`
        task_done $progress_url > /tmp/tmp  2>&1
        ;;
    get)
        LOG "I" "Getting instance '$NAME' details"
        result=$(get-instance-details)
        if [ $ONLY_IP ] ; then 
            echo $result | jq --raw-output ".networkInterfaces[0].accessConfigs[0].natIP"
        else
            echo $result
        fi
        ;;
    me)
        LOG "I" "Getting user info"
        api="https://www.googleapis.com/plus/v1/people/me"
        url="$api?access_token=$ACCESS_TOKEN"
        LOG "D" "GET $url"
        result=`curl -s $url`
        LOG "D" "Response $result"
        if [ $EMAIL ]; then
           echo $result | jq --raw-output ".emails[0].value"
        else
           echo $result
        fi
        ;;
esac

exit 0
