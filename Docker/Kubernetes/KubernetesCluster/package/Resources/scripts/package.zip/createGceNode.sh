#!/bin/bash
# This script adds GCE node to Murano k8s cluster.

set -e

LOG_FILE="/var/log/gce.log"
SCRIPTS_PATH="/opt/bin/autoscale/gce"
conf_file="/etc/autoscale/autoscale.conf"
PROJ_ID=$(awk -F "=" '/^GCP_PROJECT_ID/ {print $2}' $conf_file)
if [ -z $PROJ_ID ] ; then
    echo "Error: PROJECT ID not found"
    exit 1
fi
# RANDOM_STR=`cat /dev/urandom | tr -dc 'a-z0-9' | fold -w ${1:-12} | head -n 1`
RANDOM_STR=`date +"d%Y%m%d-t%H%M%S"`

NAME="murano-k8s-$RANDOM_STR"
function LOG()
{
    echo $1 >> $LOG_FILE
}

LOG "Creating boot disk '$NAME'"
bash ${SCRIPTS_PATH}/compute_api.sh create-disk -n $NAME -p $PROJ_ID
LOG "Creating instance '$NAME'"
bash ${SCRIPTS_PATH}/compute_api.sh insert -n $NAME -p $PROJ_ID
IP=$(bash ${SCRIPTS_PATH}/compute_api.sh get --ip -n $NAME -p $PROJ_ID)
LOG "Instance created with external IP '$IP'"
echo $IP
sleep 5
exit 0
